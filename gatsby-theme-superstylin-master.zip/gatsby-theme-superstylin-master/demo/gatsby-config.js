module.exports = {
  plugins: ['gatsby-theme-superstylin']
}
