import React from 'react'

import Layout from '../components/layouts'
import Hero from '../components/Hero'

export default () => (
  <Layout>
    <Hero />
  </Layout>
)
